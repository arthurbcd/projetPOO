package org.biart.poo.state;

public interface SessionState {
    

}
