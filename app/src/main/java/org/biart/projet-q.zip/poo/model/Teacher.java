package org.biart.poo.model;
import java.util.List;

public class Teacher {
    private String id;                    
    private String name;                   
    private List<String> specialites; 
}
