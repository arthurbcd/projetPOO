package org.biart.poo.model;

public enum Category {
    INFORMATICS,
    MANAGEMENT,
    LANGUAGES
}
