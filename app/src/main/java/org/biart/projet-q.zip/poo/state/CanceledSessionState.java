package org.biart.poo.state;

public class CanceledSessionState implements SessionState {

}
