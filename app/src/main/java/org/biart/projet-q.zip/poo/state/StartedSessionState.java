package org.biart.poo.state;

public class StartedSessionState implements SessionState {

}
