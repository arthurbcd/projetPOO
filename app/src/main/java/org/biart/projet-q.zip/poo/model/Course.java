package org.biart.poo.model;

public class Course {

}
