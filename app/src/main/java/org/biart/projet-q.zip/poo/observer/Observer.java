package org.biart.poo.observer;

public interface Observer {
    void update(Observable observable, Object arg);
}
