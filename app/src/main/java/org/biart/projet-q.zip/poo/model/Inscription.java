package org.biart.poo.model;

public class Inscription {

}
