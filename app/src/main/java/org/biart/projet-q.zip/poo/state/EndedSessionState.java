package org.biart.poo.state;

public class EndedSessionState implements SessionState {

}
