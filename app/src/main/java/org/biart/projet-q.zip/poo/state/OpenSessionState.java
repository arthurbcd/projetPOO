package org.biart.poo.state;

public class OpenSessionState implements SessionState {

}
