package org.biart.poo.state;

public class FullSessionState implements SessionState {

}
